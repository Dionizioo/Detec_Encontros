const fs = require("fs");
const path = require("path");

const arquivos = [
    "respostas1.json",
    "respostas2.json"
];

for (const arquivo of arquivos) {

    const caminho = path.join(__dirname, "../datasets", arquivo);

    if (!fs.existsSync(caminho)) {
        console.log(`Arquivo não encontrado: ${arquivo}`);
        continue;
    }

    const dados = JSON.parse(fs.readFileSync(caminho, "utf8"));

    console.log(`\n===== ${arquivo} =====`);

    console.log("Total de encontros:", dados.length);

    const contagem = {};

    for (const encontro of dados) {
        contagem[encontro.tipo] = (contagem[encontro.tipo] || 0) + 1;
    }

    console.log("Quantidade por tipo:", contagem);

    console.log("Primeiros 5 encontros:");

    console.log(JSON.stringify(dados.slice(0, 5), null, 2));
}