const RAIO_TERRA = 6371000;

function paraRadiano(graus) {
  return graus * Math.PI / 180;
}

function calcularDistancia(lat1, lon1, lat2, lon2) {
  const latitude1 = paraRadiano(lat1);
  const latitude2 = paraRadiano(lat2);
  const diferencaLatitude = paraRadiano(lat2 - lat1);
  const diferencaLongitude = paraRadiano(lon2 - lon1);

  const a = Math.sin(diferencaLatitude / 2) * Math.sin(diferencaLatitude / 2) +
    Math.cos(latitude1) * Math.cos(latitude2) *
    Math.sin(diferencaLongitude / 2) * Math.sin(diferencaLongitude / 2);

  const valorLimitado = Math.min(1, Math.max(0, a));
  const angulo = 2 * Math.atan2(Math.sqrt(valorLimitado), Math.sqrt(1 - valorLimitado));

  return RAIO_TERRA * angulo;
}

module.exports = { calcularDistancia };
