const haversine = require("./haversine");

function detectarParesProximos(monitores) {
  const grupos = {};

  for (let i = 0; i < monitores.length; i++) {
    const monitorado = monitores[i];
    const timestamp = monitorado.timestamp;

    if (!grupos[timestamp]) {
      grupos[timestamp] = [];
    }

    grupos[timestamp].push(monitorado);
  }

  const encontros = [];
  const encontrosPorPar = {};
  const timestamps = Object.keys(grupos);

  for (let t = 0; t < timestamps.length; t++) {
    const timestamp = timestamps[t];
    const grupo = grupos[timestamp];

    for (let i = 0; i < grupo.length; i++) {
      for (let j = i + 1; j < grupo.length; j++) {
        const monitorado1 = grupo[i];
        const monitorado2 = grupo[j];

        if (monitorado1.idMonitorado === monitorado2.idMonitorado) {
          continue;
        }

        const distancia = haversine.calcularDistancia(
          monitorado1.latitude,
          monitorado1.longitude,
          monitorado2.latitude,
          monitorado2.longitude
        );

        if (distancia >= 20) {
          continue;
        }

        const idMenor = Math.min(monitorado1.idMonitorado, monitorado2.idMonitorado);
        const idMaior = Math.max(monitorado1.idMonitorado, monitorado2.idMonitorado);
        const chave = timestamp + "|" + idMenor + "|" + idMaior;

        if (encontrosPorPar[chave] === undefined) {
          encontrosPorPar[chave] = encontros.length;
          encontros.push({
            timestamp: timestamp,
            monitorado1: monitorado1,
            monitorado2: monitorado2,
            distanciaMetros: distancia
          });
        } else {
          const indice = encontrosPorPar[chave];
          if (distancia < encontros[indice].distanciaMetros) {
            encontros[indice] = {
              timestamp: timestamp,
              monitorado1: monitorado1,
              monitorado2: monitorado2,
              distanciaMetros: distancia
            };
          }
        }
      }
    }
  }

  return encontros;
}

module.exports = { detectarParesProximos: detectarParesProximos };
