const fs = require("fs");
const path = require("path");

const { dataset } = require("./parser");
const { detectarParesProximos } = require("./detector_to");

// Lê o dataset 1
const caminho = path.join(__dirname, "../datasets/dataset1.txt");
const conteudo = fs.readFileSync(caminho, "utf8");

// Converte o arquivo em objetos
const monitores = dataset(conteudo);

// Procura pares próximos
const encontros = detectarParesProximos(monitores);

console.log("Total de posicionamentos:", monitores.length);
console.log("Total de pares próximos:", encontros.length);

console.log("\nPrimeiros pares encontrados:");

console.log(
    JSON.stringify(
        encontros.map(encontro => ({
            timestamp: encontro.timestamp,
            id1: encontro.monitorado1.idMonitorado,
            faccao1: encontro.monitorado1.faccaoMonitorado,
            medida1: encontro.monitorado1.medidaProtetiva,
            restricoes1: encontro.monitorado1.idsRestricaoMedida,

            id2: encontro.monitorado2.idMonitorado,
            faccao2: encontro.monitorado2.faccaoMonitorado,
            medida2: encontro.monitorado2.medidaProtetiva,
            restricoes2: encontro.monitorado2.idsRestricaoMedida,

            distancia: encontro.distanciaMetros
        })),
        null,
        2
    )
);