const fs = require("fs");
const path = require("path");
const readline = require("readline");
const parser = require("./parser");
const detector = require("./detector_to");

function mesmoVinculoProtetivo(a, b) {
  const bEstaNaLista = a.idsRestricaoMedida.indexOf(b.idMonitorado) !== -1;
  const aEstaNaLista = b.idsRestricaoMedida.indexOf(a.idMonitorado) !== -1;
  return (a.medidaProtetiva && bEstaNaLista) || (b.medidaProtetiva && aEstaNaLista);
}

function tipoEncontro(a, b) {
  if (mesmoVinculoProtetivo(a, b)) {
    return "protetiva";
  }

  if (a.faccaoMonitorado && a.faccaoMonitorado === b.faccaoMonitorado) {
    return "faccao";
  }

  return "generico";
}

function gerarEncontros(monitores) {
  const pares = detector.detectarParesProximos(monitores);
  const encontros = [];

  for (let i = 0; i < pares.length; i++) {
    const par = pares[i];
    let primeiro = par.monitorado1;
    let segundo = par.monitorado2;

    if (primeiro.idMonitorado > segundo.idMonitorado) {
      primeiro = par.monitorado2;
      segundo = par.monitorado1;
    }

    const posicoes = {};
    posicoes[primeiro.idMonitorado] = {
      lat: primeiro.latitude,
      lon: primeiro.longitude
    };
    posicoes[segundo.idMonitorado] = {
      lat: segundo.latitude,
      lon: segundo.longitude
    };

    encontros.push({
      tipo: tipoEncontro(primeiro, segundo),
      monitoradosEncontro: [primeiro.idMonitorado, segundo.idMonitorado],
      timestamp: par.timestamp,
      posicoes: posicoes,
      distanciaMetros: par.distanciaMetros
    });
  }

  return encontros;
}

async function processarArquivo(entrada, saida) {
  const leitor = readline.createInterface({
    input: fs.createReadStream(entrada, { encoding: "utf8" }),
    crlfDelay: Infinity
  });
  const encontros = [];
  let grupo = [];
  let timestampAtual = null;
  let totalRegistros = 0;
  let numeroLinha = 0;

  for await (const linha of leitor) {
    numeroLinha++;
    const monitorado = parser.parseLinha(linha, numeroLinha);

    if (!monitorado) {
      continue;
    }

    if (timestampAtual !== null && monitorado.timestamp !== timestampAtual) {
      const encontrosDoGrupo = gerarEncontros(grupo);
      for (let i = 0; i < encontrosDoGrupo.length; i++) {
        encontros.push(encontrosDoGrupo[i]);
      }
      grupo = [];
    }

    timestampAtual = monitorado.timestamp;
    grupo.push(monitorado);
    totalRegistros++;
  }

  if (grupo.length > 0) {
    const encontrosDoGrupo = gerarEncontros(grupo);
    for (let i = 0; i < encontrosDoGrupo.length; i++) {
      encontros.push(encontrosDoGrupo[i]);
    }
  }

  fs.mkdirSync(path.dirname(saida), { recursive: true });
  fs.writeFileSync(saida, JSON.stringify(encontros, null, 2) + "\n", "utf8");
  console.log(path.basename(entrada) + ": " + totalRegistros + " posições, " +
    encontros.length + " encontros -> " + saida);
}

async function main() {
  const raiz = path.resolve(__dirname, "..");
  const pastaDados = path.join(raiz, "datasets");
  const pastaSaida = path.join(raiz, "outputs");
  const argumentos = process.argv.slice(2);
  let arquivos = argumentos;

  if (arquivos.length === 0) {
    arquivos = fs.readdirSync(pastaDados).filter(function (nome) {
      return /^dataset\d+\.txt$/i.test(nome);
    }).sort();
  }

  for (let i = 0; i < arquivos.length; i++) {
    const nome = arquivos[i];
    const entrada = path.resolve(pastaDados, nome);

    if (path.dirname(entrada) !== pastaDados || !fs.existsSync(entrada)) {
      throw new Error("Dataset não encontrado em datasets/: " + nome);
    }

    const nomeSaida = path.basename(nome, path.extname(nome)) + ".json";
    await processarArquivo(entrada, path.join(pastaSaida, nomeSaida));
  }
}

if (require.main === module) {
  main().catch(function (erro) {
    console.error(erro.message);
    process.exitCode = 1;
  });
}

module.exports = { gerarEncontros, tipoEncontro };
