const { calcularDistancia } = require("./haversine");

// Teste 1: coordenadas iguais
const distancia1 = calcularDistancia(
    0, 0,
    0, 0
);

// Teste 2: posições próximas
const distancia2 = calcularDistancia(
    0, 0,
    0, 0.0001
);

console.log("Teste 1:", distancia1, "metros");
console.log("Teste 2:", distancia2, "metros");