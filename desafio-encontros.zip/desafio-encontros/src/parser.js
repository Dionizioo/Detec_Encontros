function tirarAspas(valor) {
  return valor.trim().replace(/^"|"$/g, "");
}

function parseLinha(linha, numeroLinha) {
  linha = linha.trim();

  if (linha === "" || linha.indexOf("idMonitorado;") === 0) {
    return null;
  }

  const campos = linha.split(";");
  if (campos.length !== 7) {
    throw new Error("Linha " + numeroLinha + " inválida: " + linha);
  }

  const idMonitorado = Number(campos[0].trim());
  const faccaoMonitorado = campos[1].trim();
  const timestamp = tirarAspas(campos[2]);
  const latitude = Number(campos[3].trim());
  const longitude = Number(campos[4].trim());
  const medidaTexto = campos[5].trim().toLowerCase();
  const idsTexto = tirarAspas(campos[6]);
  const idsRestricaoMedida = [];

  if (medidaTexto !== "true" && medidaTexto !== "false") {
    throw new Error("Medida protetiva inválida na linha " + numeroLinha);
  }

  if (idsTexto !== "") {
    const ids = idsTexto.split(",");
    for (let i = 0; i < ids.length; i++) {
      idsRestricaoMedida.push(Number(ids[i].trim()));
    }
  }

  if (!Number.isInteger(idMonitorado) || !isFinite(latitude) || !isFinite(longitude) ||
      Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
    throw new Error("Dados inválidos na linha " + numeroLinha);
  }

  for (let i = 0; i < idsRestricaoMedida.length; i++) {
    if (!Number.isInteger(idsRestricaoMedida[i])) {
      throw new Error("ID de restrição inválido na linha " + numeroLinha);
    }
  }

  return {
    idMonitorado: idMonitorado,
    faccaoMonitorado: faccaoMonitorado || null,
    timestamp: timestamp,
    latitude: latitude,
    longitude: longitude,
    medidaProtetiva: medidaTexto === "true",
    idsRestricaoMedida: idsRestricaoMedida
  };
}

function dataset(conteudo) {
  const linhas = conteudo.replace(/^\uFEFF/, "").split(/\r?\n/);
  const monitores = [];

  for (let i = 0; i < linhas.length; i++) {
    const monitorado = parseLinha(linhas[i], i + 1);
    if (monitorado) {
      monitores.push(monitorado);
    }
  }

  return monitores;
}

module.exports = { dataset: dataset, parseLinha: parseLinha };
